-- Bases de Datos II - Unidad 7 - Food Store
-- Ejecutar en la base Food Store del repositorio.
-- El seed público contiene pedidos 1, 2 y 3 y productos/clientes sintéticos.
-- Este bloque completa los pedidos 4 y 5 para el laboratorio, si esos IDs están libres.
-- En una base con otros datos, adaptar IDs y seleccionar al menos cinco pedidos reales.

-- Pedidos de laboratorio adicionales. La fecha se asigna por DEFAULT.
INSERT INTO pedido (id_pedido, estado, forma_pago, cliente_id)
OVERRIDING SYSTEM VALUE
VALUES
  (4, 'PENDIENTE', 'EFECTIVO', 1),
  (5, 'PENDIENTE', 'TARJETA', 1)
ON CONFLICT (id_pedido) DO NOTHING;

-- Líneas de ejemplo para que los cinco pedidos tengan detalle.
-- Precios históricos conservados en detalle_pedido; no se toma el precio actual
-- de producto para reconstruir ventas anteriores.
INSERT INTO detalle_pedido (id_pedido, id_producto, precio_unitario, cantidad)
VALUES
  (1, 1, 1000.00, 1), (1, 3, 900.00, 1),
  (2, 1, 1000.00, 2),
  (3, 3, 900.00, 2), (3, 1, 1000.00, 1),
  (4, 1, 1000.00, 3),
  (5, 3, 900.00, 1), (5, 1, 1000.00, 2)
ON CONFLICT (id_pedido, id_producto) DO NOTHING;

-- Ajustar secuencia si se usaron IDs explícitos.
SELECT setval(pg_get_serial_sequence('pedido', 'id_pedido'),
              GREATEST((SELECT COALESCE(MAX(id_pedido), 1) FROM pedido), 1));

-- Consulta equivalente a MongoDB 4b: pedidos en estado PENDIENTE.
SELECT id_pedido, estado
FROM pedido
WHERE estado = 'PENDIENTE'
ORDER BY id_pedido;

-- Consulta equivalente a MongoDB 4c: pedidos con el producto 1.
SELECT DISTINCT dp.id_pedido
FROM detalle_pedido AS dp
WHERE dp.id_producto = 1
ORDER BY dp.id_pedido;

-- Datos comparables para registrar cantidades e IDs tras ejecutar.
SELECT 'estado=PENDIENTE' AS criterio,
       COUNT(*) AS cantidad,
       ARRAY_AGG(id_pedido ORDER BY id_pedido) AS ids
FROM pedido
WHERE estado = 'PENDIENTE'
UNION ALL
SELECT 'producto id=1',
       COUNT(DISTINCT id_pedido),
       ARRAY_AGG(DISTINCT id_pedido ORDER BY id_pedido)
FROM detalle_pedido
WHERE id_producto = 1;

-- Verificar importes por pedido a partir del precio histórico de cada línea.
SELECT p.id_pedido,
       SUM(dp.cantidad * dp.precio_unitario) AS total_calculado
FROM pedido p
JOIN detalle_pedido dp ON dp.id_pedido = p.id_pedido
GROUP BY p.id_pedido
ORDER BY p.id_pedido;
