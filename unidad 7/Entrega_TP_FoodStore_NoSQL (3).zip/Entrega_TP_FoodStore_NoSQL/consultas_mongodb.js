// Bases de Datos II - Unidad 7 - Food Store
// Ejecutar con mongosh. Los documentos de ejemplo son datos de laboratorio.
// Colección: pedidos. Se conserva el ID relacional en id_pedido.
db = db.getSiblingDB("food_store_nosql");

db.pedidos.createIndex({ id_pedido: 1 }, { unique: true });
db.pedidos.createIndex({ estado: 1 });
db.pedidos.createIndex({ "productos.id_producto": 1 });

// Inserción reproducible de cinco pedidos de prueba.
// Si ya existen estos IDs, limpiar SOLO esta colección de laboratorio antes de insertar:
// db.pedidos.deleteMany({});
db.pedidos.insertMany([
  {
    _id: 1, id_pedido: 1, fecha: ISODate("2026-10-01T12:00:00Z"),
    estado: "PENDIENTE", forma_pago: "EFECTIVO",
    cliente: { id_cliente: 1, nombre: "Ana", apellido: "Prueba",
               correo_electronico: "cliente1@example.test" },
    productos: [
      { id_producto: 1, nombre: "Muzzarella de prueba", cantidad: 1, precio_unitario: 1000.00 },
      { id_producto: 3, nombre: "Bebida activa de prueba", cantidad: 1, precio_unitario: 900.00 }
    ],
    total: 1900.00, origen_datos: "laboratorio"
  },
  {
    _id: 2, id_pedido: 2, fecha: ISODate("2026-10-02T12:00:00Z"),
    estado: "PENDIENTE", forma_pago: "TARJETA",
    cliente: { id_cliente: 1, nombre: "Ana", apellido: "Prueba",
               correo_electronico: "cliente1@example.test" },
    productos: [
      { id_producto: 1, nombre: "Muzzarella de prueba", cantidad: 2, precio_unitario: 1000.00 }
    ],
    total: 2000.00, origen_datos: "laboratorio"
  },
  {
    _id: 3, id_pedido: 3, fecha: ISODate("2026-10-03T12:00:00Z"),
    estado: "PENDIENTE", forma_pago: "TRANSFERENCIA",
    cliente: { id_cliente: 1, nombre: "Ana", apellido: "Prueba",
               correo_electronico: "cliente1@example.test" },
    productos: [
      { id_producto: 3, nombre: "Bebida activa de prueba", cantidad: 2, precio_unitario: 900.00 },
      { id_producto: 1, nombre: "Muzzarella de prueba", cantidad: 1, precio_unitario: 1000.00 }
    ],
    total: 2800.00, origen_datos: "laboratorio"
  },
  {
    _id: 4, id_pedido: 4, fecha: ISODate("2026-10-04T12:00:00Z"),
    estado: "PENDIENTE", forma_pago: "EFECTIVO",
    cliente: { id_cliente: 1, nombre: "Ana", apellido: "Prueba",
               correo_electronico: "cliente1@example.test" },
    productos: [
      { id_producto: 1, nombre: "Muzzarella de prueba", cantidad: 3, precio_unitario: 1000.00 }
    ],
    total: 3000.00, origen_datos: "laboratorio"
  },
  {
    _id: 5, id_pedido: 5, fecha: ISODate("2026-10-05T12:00:00Z"),
    estado: "PENDIENTE", forma_pago: "TARJETA",
    cliente: { id_cliente: 1, nombre: "Ana", apellido: "Prueba",
               correo_electronico: "cliente1@example.test" },
    productos: [
      { id_producto: 3, nombre: "Bebida activa de prueba", cantidad: 1, precio_unitario: 900.00 },
      { id_producto: 1, nombre: "Muzzarella de prueba", cantidad: 2, precio_unitario: 1000.00 }
    ],
    total: 2900.00, origen_datos: "laboratorio"
  }
]);

// 4a) Todos los pedidos: identificador y estado.
db.pedidos.find({}, { _id: 0, id_pedido: 1, estado: 1 }).sort({ id_pedido: 1 });

// 4b) Filtrar por un estado presente en los datos.
db.pedidos.find({ estado: "PENDIENTE" }, { _id: 0, id_pedido: 1, estado: 1 });

// 4c) Pedidos que contienen el producto seleccionado (id_producto = 1).
db.pedidos.find(
  { "productos.id_producto": 1 },
  { _id: 0, id_pedido: 1, "productos.$": 1 }
).sort({ id_pedido: 1 });

// 4d) Total superior a $2.000; el umbral separa pedidos de mayor importe
// de los pedidos de importe igual o inferior al valor elegido.
db.pedidos.find({ total: { $gt: 2000 } },
  { _id: 0, id_pedido: 1, total: 1 }).sort({ total: -1 });

// Comprobaciones auxiliares: documentos y consistencia del total.
db.pedidos.countDocuments({});
db.pedidos.find({}, {
  _id: 0, id_pedido: 1,
  total_documento: "$total"
}).sort({ id_pedido: 1 });

// Validar que total = suma de cantidad * precio_unitario.
db.pedidos.aggregate([
  { $project: {
      id_pedido: 1,
      total_guardado: "$total",
      total_calculado: { $sum: { $map: {
        input: "$productos",
        as: "p",
        in: { $multiply: ["$$p.cantidad", "$$p.precio_unitario"] }
      }}}
  }},
  { $project: {
      id_pedido: 1, total_guardado: 1, total_calculado: 1,
      coincide: { $eq: ["$total_guardado", "$total_calculado"] }
  }}
]);
